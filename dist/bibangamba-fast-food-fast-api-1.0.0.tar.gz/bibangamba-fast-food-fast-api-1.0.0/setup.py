from setuptools import setup, find_packages

setup(name='bibangamba-fast-food-fast-api',
      version='1.0.0',
      description='api endpoints project for andela developer challenge 2',
      author='andrew twijukye',
      author_email='andrewbibangamba@gmail.com',
      url='https://github.com/bibangamba/fast-food-fast/tree/api_v1',
      packages=find_packages(exclude=['contrib', 'docs', 'tests*']),
     )